﻿<div id="wrapper">
  <ul id="tabs">
    <li><a href="#about">Folkpartiet</a></li>
    <li><a href="#advantages">Om Direktdemokraterna</a></li>
    <li><a href="#usage">Placeholder</a></li>
  </ul>

  <div class="tabContent" id="about">
    <h2>Om Folkpartiet</h2>
  </div>

  <div class="tabContent" id="advantages">

  </div>

  <div class="tabContent" id="usage">

  </div>
</div>