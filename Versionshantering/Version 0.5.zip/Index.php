﻿<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;"> 
    <title>DD Demo</title>    
    <link rel="stylesheet" type="text/css" href="myCss.css">
    <script src="Javascript.js"></script>
  </head>  
  <body onload="init()">
  
  <a href="index.php"><img src="logo.png" id="logo"></a>
  <div id="wrapper">
    <ul id="tabs">
      <li><a href="#about">Partier</a></li>
      <li><a href="#advantages">Om Direktdemokraterna</a></li>
      <li><a href="#usage">Using tabs</a></li>
    </ul>

    <div class="tabContent" id="about">
      <h2>Välj ett parti</h2>      
      <form method="post" action="index.php">
        <table style="width:10%">
          <tr>
            <td>  
              <label>
                <input type="radio" name="parti" value="1"/>
                <a href="c.php"> 
                  <img src="parti1.png" align="center" >    
                </a>                
              </label>
              <p>C</p>
            </td>
            <td>  
              <label>                
                <input type="radio" name="parti" value="2"/>
                <a href="fp.php"> 
                  <img src="parti2.png" align="center">                
                </a>                
              </label>
              <p>FP</p>
            </td>
          </tr>
          <tr>
            <td>  
              <label>
                <input type="radio" name="parti" value="3"/>
                <a href="kd.php"> 
                  <img src="parti3.png">
                </a>                
              </label>
              <p>KD</p>
            </td>
            <td>  
              <label>
                <input type="radio" name="parti" value="4"/>
                <a href="m.php"> 
                  <img src="parti4.png">
                </a>
              </label>
              <p>M</p>
            </td>
          </tr>
          <tr>
            <td>  
              <label>
                <input type="radio" name="parti" value="5"/>
                <a href="mp.php"> 
                  <img src="parti5.png">
                </a>
              </label>
              <p>MP</p>
            </td>
            <td>  
              <label>
                <input type="radio" name="parti" value="6"/>
                <a href="s.php"> 
                  <img src="parti6.png">
                </a>
              </label>
              <p>S</p>
            </td>
          </tr>
          <tr>
            <td>  
              <label>
                <input type="radio" name="parti" value="7"/>
                <a href="sd.php"> 
                  <img src="parti7.png">
                </a>
              </label>
              <p>SD</p>
            </td>
            <td>  
              <label>
                <input type="radio" name="parti" value="8"/>
                <a href="v.php"> 
                  <img src="parti8.png">
                </a>
              </label>
              <p>V</p>
            </td>
          </tr>
        </table>
      </form>      
    </div>

    <div class="tabContent" id="advantages">
      <h2>Advantages of tabs</h2>
      <div>
        <p>Lorem ipsum används ofta som exempeltext inom tr<br>
        ycksaksframställning och grafisk design för <br>
        att visa hur till exempel ett dokument kommer att se ut när väl den ...</p>
      </div>
    </div>

    <div class="tabContent" id="usage">
      <h2>Using tabs</h2>
      <div>
        <p>Click a tab to view the tab's content. Using tabs couldn't be easier!</p>
      </div>
    </div>
  </div>
  </body>  
</html>

<?php
$a = @$_POST['parti'];
echo "Du röstade på"." ".$a;


?>